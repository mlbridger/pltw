again = True
def assignment1():
    print "Assignment 1 completed."

def assignment2(): 
    print "Assignment 2 completed."

'''
def assignment2(): 
    return "Assignment 2 completed."
#Adding this line stores the value to a variable
assignment2_result = assignment2()
#Adding this line allows us to see that variable
print assignment2_result
'''

while again == True:
    number = raw_input("What assignment would you like to execute?")
    
    def execute_assignment(assignment_number):
        if assignment_number == "1":
            assignment1()
        elif assignment_number == "2":
            assignment2()
            
    execute_assignment(number)
    
    again_feedback = raw_input("Enter Quit to Quit, or anything else to call another assignment?")
    if again_feedback == "Quit":
        again = False
    else:
        again = True