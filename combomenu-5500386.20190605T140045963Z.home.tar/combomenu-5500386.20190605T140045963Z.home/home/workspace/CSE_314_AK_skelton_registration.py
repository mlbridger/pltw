from CSE_314_course import Course
from CSE_314_AK_skeleton_student import Student

math = Course("Algebra I")
language = Course("Spanish I")
science = Course("Earth Science")
history = Course("U.S. History I")
phys_ed = Course("Physical Education I")
english = Course("American Literature")
# Add two more courses of your choosing
PLTW_eng = Course("PLTW Engineering")
PLTW_bioMed = Course("PLTW BioMedical")

test_student = Student("Jill", "Sample")

test_student.add_course(math)
test_student.add_course(language)
test_student.add_course(science)
test_student.add_course(history)

test_student2 = Student("Bill", "Sample")

test_student2.add_course(math)
test_student2.add_course(phys_ed)
test_student2.add_course(science)
test_student2.add_course(history)

#TODO Add a third test student and assign them four classes
test_student3 = Student("Richard", "Sample")

test_student3.add_course(math)
test_student3.add_course(PLTW_eng)
test_student3.add_course(science)
test_student3.add_course(PLTW_bioMed)

#TODO Add all the test students to a list of your own creation,
student_list = [test_student, test_student2, test_student3]
print student_list

#iterate over each of the students in the list and print their names and course schedules.
for student in student_list:
    #Each iteration should get,concatenate, and print the first and last name 
    '''for this part you may need to review the other skeleton 
       to see how to get items from a list
       Also, review syntax of pulling items from a list in the 3.1.3 activities'''
    print student.get_first_name() + "\t" + student.get_last_name()
    #Then it should loop through
    for course in student.courses:
        #to print each course
        print course
    #When the loop is done, it should print to the next line for readability
    print "\n"
    