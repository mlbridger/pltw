"""
This program is intended as a tracer round for the flow of control as a user
of a social media account makes, deletes, and edits posts. For testing,
a user should be able to enter their user name, change which user name they
are currently using, add a post using their current user name, remove a post
made under their current user name, edit a post made under their current user 
name, print the contents of the list of posts, or quit the program.
"""

#This line of code tells the Python interpreter that it needs to reference the 
#post.py file in order to run the rest of the code in this file.
from CSE_313_post import Post

#Store initial user input in a variable identified by user_input
#You may need to use this statement again to complete the activity.
user_input = raw_input(""" What would you like to do?
"add" - Add a post to the archive
"remove" - Remove a post from the archive
"change user" - Change the user name associated with any future posts
"print" - Display the current up to date list of all posts
"quit" - End the program
""")

#Where are we posting to in this code?
to_post_list = []

#Who is posting?
user_name = raw_input("What is your professional username?")

#This while loop ensures that the program will continue executing statements
# at the next indentation level until the user types "quit" in response to the 
# prompt.
while user_input != "quit":

    #code for adding a post here
    if user_input == "add":
        message = raw_input("What is your message to add?")
        post = Post(user_name, message)
        to_post_list.append(post)

    #code for removing a post here
    elif user_input == "remove":
        index_to_remove = int(raw_input("What is the index number you want to remove?"))
        del to_post_list[index_to_remove]
    
    #code for changing the current user here
    elif user_input == "change user":
        user_name = raw_input("What username would like you to use now?")
        
    #code to display all posts, you can use the code in comments below
    elif user_input == "print":
        for post in to_post_list:
            print post
    
    #code to inform the user that their input was not valid here
    else:
        print "That command is not recognized. Please Try again."
        


    user_input = raw_input(""" What would you like to do?
    "add" - Add a post to the archive
    "remove" - Remove a post from the archive
    "change user" - Change the user name associated with any future posts
    "print" - Display the current up to date list of all posts
    "quit" - End the program
    
    """)