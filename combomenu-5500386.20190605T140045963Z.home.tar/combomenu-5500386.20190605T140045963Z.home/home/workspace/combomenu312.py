'''
3.1.2 Combo Menu
'''

#Initialize the total to 0
total = 0

#Ask the user a type of sandwich
#Chicken $5.25, beef $6.25, tofu $5.75
print ("What type of sanwich would you like?")
print ("c for chicken, b for beef, t for tofu")
sandwich = raw_input("Enter your sanwich type: ")

if sandwich == "c":
    total += 5.25
elif sandwich == "b":
    total += 6.25
elif sandwich == "t":
    total += 5.75
else:
    print "wrong character"
print "your total is $" + str(total)

#Drink? If yes, ask for your size!
drink_response = raw_input("Would you like a drink? (y for yes, n for no)")
if drink_response == "y":
    print "Okay, what size would you like?"
    size = raw_input("Enter s for small m for medium, l for large: ")
    if size == "s":
        total += 1.00
    if size == "m":
        total += 1.75
    if size == "l":
        total += 2.25
    print "Your updated total is $" + str(total) + "."
else:
    print "okay, no drink"
    
#Fries? If yes, ask for your size!
fry_order = raw_input("Would you like fries with that, yes or no?")
if fry_order == "yes":
    fry_size = raw_input("Would you like a small for ($1.00), medium for ($1.50), or large for ($2.00)? ")
    if fry_size == "small":
        mega_size = raw_input("Would you like to mega size, yes or no")
        if mega_ size == "yes"