#Initiaize the running count of price
cost = 0

#This segment sets up a Boolean way to evaulate what has been bought
#this part is not needed till the last part of reducing the cost for a combo
#It makes all true, so the person will by default will get a discount 
#unless they do not order one & it changes to false
sandwhich = True
fries = True
drink = True

#Part 1, getting the food order
#Get user input and put it through conditional to add to price
food = raw_input("Do you want chicken ($5.25), beef ($6.25), tofu ($5.75), or no food?")
if food == "chicken":
    cost = cost + 5.25 
    
    '''
    The cost = Cost + $ can also be done as cost += $
    the += is an arthemetic operator that adds the variable itself plus what is listed after
    so it could also look like:
    cost += 5.25
    '''
    
elif food == "beef":
    cost = cost + 6.25
elif food == "tofu":
    cost = cost + 5.75
else:
    print "You did not buy any food"
    sandwhich = False #This line only gets added during the last part of the activity

'''
Iteration contorl
print (cost)
add this print line after the first part
then move it to be after each part as you add
this allows you to check the code each time
'''


#Part 2, getting the drink order
drink_order = raw_input("Would you like a drink with that, yes or no?")
if drink_order == "yes":
    drink_size = raw_input("Small ($1.00), medium ($1.75), or large ($2.25)?")
    if drink_size == "small":
        cost += 1
    elif drink_size == "medium":
        cost += 1.75
    elif drink_size == "large":
        cost += 2.25
    else:
        print("Alright, no drink for you.")
        drink = False #This line only gets added during the last part of the activity
else:
    print "Got it. No drink."
    drink = False #This line only gets added during the last part of the activity


#Part 3, getting the fry order
fry_order = raw_input("Would you like fries with that, yes or no?")
if fry_order == "yes":
    fry_size = raw_input("Would you like a Small ($1.00), medium ($1.50), or large ($2.00)?")
    if fry_size == "small":
        mega_size = raw_input("Would you like to megae size, yes or no?")
        if mega_size == "yes":
            cost += 2.25
        else:
            cost += 1
    elif fry_size == "medium":
        cost += 1.75
    elif fry_size == "large":
        cost += 2.25
    else:
        print "Alright, no fries for you."
        fries = False #This line only gets added during the last part of the activity
else:
    print("Got it. No fries.")
    fries = False #This line only gets added during the last part of the activity

#getting the number of ketchup packets
number_ketchup_packets = int(raw_input("How many ketchup packets would you like? "))
cost += 0.25 * number_ketchup_packets


#checking if person gets combo discount
if sandwhich == True and drink == True and fries == True:
    cost -= 1
    print "Combo Discount"
    
    
#Doing the final report of what was bought and the price
print "I have your order as:"
if sandwhich == True:
    print food, "sandwhich"
if drink == True:
        print drink_size, "drink" #The , between items does concatentation
if fries == True:
    print fry_size, "Fries"
if number_ketchup_packets > 0:
    print number_ketchup_packets, "ketchup packets"
print cost, "is your total."