cost = 0
#This segment sets up a Boolean way to evaulate what has been bought
#this part is not needed till the last part of reducing the cost for a combo
#It makes all true, so the person will by default will get a discount 
#unless they do not order one & it changes to false
pizza = True
wings = True
salad = True
#Part 1, getting the pizza order
#Get user input and put it through conditional to add to price
#Buy your pizza here
pizza = raw_input("Do you want a small (10.00), medium ($12.00), large ($14.00), or no pizza?")
if pizza == "small":
    cost = cost + 10.00
    
    '''
    The cost = Cost + $ can also be done as cost += $
    the += is an arthemetic operator that adds the variable itself plus what is listed after
    so it could also look like:
    cost += 5.25
    '''
    
elif pizza == "medium":
    cost = cost + 12.00
elif pizza == "large":
    cost = cost + 14.00
else:
    print "You did not buy any pizza"
    pizza = False #This line only gets added during the last part of the activity

'''
Iteration contorl
print (cost)
add this print line after the first part
then move it to be after each part as you add
this allows you to check the code each time
'''


#Part 2, getting the wings order
wings = raw_input("Would you like an order of wings with that, yes or no?")
if wings == "yes":
    #Small is 10, Medioum is 20,and large is 30
    wings_size = raw_input("Small (10) ($8.00), medium (20) ($10.00), or large (30) ($14.00)?")
    if wings_size == "small":
        cost += 8.00
    elif wings_size == "medium":
        cost += 10.00
    elif wings_size == "large":
        cost += 14.00
    else:
        print("Alright, no wings for you.")
        wings = False #This line only gets added during the last part of the activity
else:
    print "Got it. No wings."
    wings = False #This line only gets added during the last part of the activity


#Part 3, getting A SALAD WHat FucKinG IdiOT Is ThIS!!!!!!!!!!!!!!!! DaM VeGoNS. I wILL pUt U On The PIzzA.
salad = raw_input("Would you like a salad you pice of sh*t, yes or no?")
if salad == "yes":
    salad_type = raw_input("Would you like a garden ($8.00), ceaser ($10.00), or antipasto ($12.00)?")
    if salad_type == "garden":
            cost += 8.00
    elif salad_type == "ceaser":
        cost += 10.00
    elif salad_type == "antipasto":
        cost += 12.00
    else:
        print "G00D NO SalD. YoU LIVe FoR NoW."
        salad = False #This line only gets added during the last part of the activity                
else:
    print("Got it. No salad.")
    salad = False #This line only gets added during the last part of the activity


#getting the number of toppings (max 5.)
toppings = int(raw_input("How many toppings do you want? "))
cost += 1.00 * toppings
if toppings > 5:   
    cost += 1.00 * toppings
    print("Beacse yopu selected more then 5 toppings you will be giving 5 toppings, with the prices same you selected. ")
if toppings <= 0:
    print("No toppings then.")
    
soda = int(raw_input("You can get a liter of soda for $0.75, but you have to pay for 2 liter at a time (1 set). PLs  Print how many sets you want."))
cost += 1.50 * soda
if soda <= 0:
    print ("NO Liquid tOOth kiLLer foR yuO sO Be It>")

#checking if person gets combo discount
if pizza == True and wings == True and soda == True:
    cost -= 5.25
    print "Combo Discount"
    
    
#Doing the final report of what was bought and the price
print "I have your order as:"
#if pizza == True:
print pizza, "pizza"
#if wings == True:
print wings_size, "wings" #The , between items does concatentation
#if salad == True:
print salad_type, "salad"
if toppings > 0:
    print "the prices of", toppings, "toppings"
if soda > 0:
    print soda *2, "liters of soda"
print cost, "is your total."