Total = 0

#Part 1 - What size pizza would would you like?
print ("What size pizza would you like to order?")
print (" s for small ($10.00) , m for medium ($12.00), l for large ($14.00)")
pizza = raw_input("Enter your pizza size: ")

