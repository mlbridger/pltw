world = ['w','o','r','l','d'] # This list has 5 elements. 
#Each element is assigned an index number 
#Index indicates its position in the list 
#First item/element is index 0.
#index 0 = w
#index 1 = o
#index 2 = r
#index 3 = l
#index 4 = d
#what data types are in this list? 
#Use the type() function to comfirm the data types in this list.
integers = [-3,-2,-1,0,1,2,3] 
#integers list has has 7 elements. The index or postion of -1 in the list is 2. 
floats = [-5.0, 0.5] 
#float list has has 2 elements. The index or postion of -1 in the list is 2. 
multi_type = ["hello", 2, "the", world] 
#multi_type list contains strings, an int, and a variable.
empty = [] 
#empty list has has 0 elements. 

print (world)
print (integers)
print (floats)
print (multi_type)
print (empty)

'''
The resulting outputs
['w', 'o', 'r', 'l', 'd']
[-3, -2, -1, 0, 1, 2, 3]
[-5.0, 0.5]
['hello', 2, 'the', ['w', 'o', 'r', 'l', 'd']]
[]
'''

world = [type('w'),'o','r','l','d'] # 'w' is a str at index 0
integers = [-3,-2,-1,0,1,2,3]  
floats = [-5.0, 0.5]  
empty = [] 
multi_type = ["hello", 2, "the", world] 
multi_type2 = ["hello", 2, "the", "world"] 
#The message is not quite working because of what you did to the first list. 
#Can you fix it?
#The w needs to be put back into a string, so it can not be changed. 
#"world" is one such solution that does not change what you did in first list

print (world)
print (integers)
print (floats)
print (multi_type)
print (multi_type2)
print (empty)

'''
The resulting outputs
[<type 'str'>, 'o', 'r', 'l', 'd']
[-3, -2, -1, 0, 1, 2, 3]
[-5.0, 0.5]
['hello', 2, 'the', [<type 'str'>, 'o', 'r', 'l', 'd']]
['hello', 2, 'the', 'world']
[]
'''

world = ['w','o','r','l','d'] 
integers = [-3,-2,-1,0,1,2,3] 
floats = [-5.0, 0.5]  
empty = []  
multi_type = ["hello", 2, "the", world] #The message is fixed!

print (world)
print (integers)
print (floats)
print (multi_type)
print (empty)

'''
The resulting outputs
['w', 'o', 'r', 'l', 'd']
[-3, -2, -1, 0, 1, 2, 3]
[-5.0, 0.5]
['hello', 2, 'the', ['w', 'o', 'r', 'l', 'd']]
[]
'''

print world

#Provided Example
food = ["Burger", "Shake", "Fries"] 
print food[1] + " at index 1" 
print "Is Burger in the list?:" 
print "Burger" in food
#print "Is Pizza in the food list?:" + ("Pizza" in food)
#TypeError: cannot concatenate 'str' and 'bool'objects

print ("\n")#new line

in_list = "Pizza" in food 
print "Is Pizza is in the list?: " + str(in_list)
in_list = "Burger" in food 
print "Is Burger is in the list?: " + str(in_list)
in_list = "Shake" in food 
print "Is Shake is in the list?: " + str(in_list)
in_list = "Fries" in food 
print "Is Fries is in the list?: " + str(in_list)