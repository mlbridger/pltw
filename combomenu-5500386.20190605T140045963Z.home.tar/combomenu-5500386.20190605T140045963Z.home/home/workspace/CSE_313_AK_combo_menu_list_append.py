cost = 0
selected_a_sandwhich = True
selected_a_beverage = True
selected_french_fries = True

#Setting up a list for the order
order = []

#getting the food order
food = raw_input("Do you want chicken ($5.25), beef ($6.25), tofu ($5.75), or no food?")
if food == "chicken":
    order.append(food)
    cost += 5.25 
elif food == "beef":
    order.append(food)
    cost = cost + 6.25
elif food == "tofu":
    order.append(food)
    cost = cost + 5.75
else:
    print "You did not buy any food"
    order.append('no sandwhich')
    selected_a_sandwhich = False 

#getting the drink order
drink_order = raw_input("Would you like a drink with that, yes or no?")
if drink_order == "yes":
    drink_size = raw_input("Small ($1.00), medium ($1.75), or large ($2.25)?")
    if drink_size == "small":
        order.append(drink_size)
        cost += 1
    elif drink_size == "medium":
        order.append(drink_size)
        cost += 1.75
    elif drink_size == "large":
        order.append(drink_size)
        cost += 2.25
    else:
        print("Alright, no drink for you.")
        order.append("No Drink")
        selected_a_beverage = False 
else:
    print "Got it. No drink."
    order.append("No Drink")
    selected_a_beverage = False 

#getting the fry order
fry_order = raw_input("Would you like fries with that, yes or no?")
if fry_order == "yes":
    fry_size = raw_input("Would you like a Small ($1.00), medium ($1.50), or large ($2.00)?")
    if fry_size == "small":
        mega_size = raw_input("Would you like to mega size, yes or no?")
        if mega_size == "yes":
            order.append("mega size")
            cost += 2.25
        else:
            cost += 1
    elif fry_size == "medium":
        order.append(fry_size)
        cost += 1.75
    elif fry_size == "large":
        order.append(fry_size)
        cost += 2.25
    else:
        print "Alright, no fries for you."
        order.append("No fries")
        selected_french_fries = False 
else:
    print("Got it. No fries.")
    order.append("No fries")
    selected_french_fries = False 

#getting the number of ketchup packets
number_ketchup_packets = int(raw_input("How many ketchup packets would you like? "))
order.append(number_ketchup_packets)
cost += 0.25 * number_ketchup_packets

#checking if person gets combo discount
if selected_a_sandwhich == True and selected_a_beverage == True and selected_french_fries == True:
    cost -= 1
    print "Combo Discount"
    
#Doing the final report of what was bought and the price
print "I have your order as:"
if selected_a_sandwhich == True:
    print food, "sandwhich"
if selected_a_beverage == True:
        print drink_size, "drink" 
if selected_french_fries == True:
    print fry_size, "Fries"
if number_ketchup_packets > 0:
    print number_ketchup_packets, "ketchup packets"
print cost, "is your total. and your order is", order