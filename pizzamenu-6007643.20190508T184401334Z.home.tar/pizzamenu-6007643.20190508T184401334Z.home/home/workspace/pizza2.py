Total = 0

size = True
toppings = True
wings = True
salad = True
soda = True

#Part 1, What size pizza would you like?
pizza = raw_input("What size pizza would you like? Sizes and price are: small ($10.00), medium ($12.00), large ($14.00)")
if pizza == "small":
    Total = Total + 10.00 
elif pizza == "medium":
    Total = Total + 12.00
elif food == "large":
    Total = Total + 14.00
else:
    print "You did not want a pizza?"
    sandwhich = False
    
#Part 2, How many toppings do you want?
toppings = raw_input("Would you like toppings on your pizza?  yes or no")
if toppings == "yes":
    toppings = raw_input("1 topping ($1.00), 2 toppings ($2.00), 3 toppings ($3.00), 4 toppings ($4.00), 5 toppings ($5.00).")
    if toppings == "1":
        cost += 1
    elif toppings == "2":
        cost += 2
    elif toppings == "3":
        cost += 3
    elif toppings == "4":
        cost += 4
    elif toppings == "5":
        cost += 5
    else:
        print("Ok, no toppings, just plain cheese for you.")
        drink = False 
'''
#Part 3, getting the fry order
fry_order = raw_input("Would you like fries with that, yes or no?")
if fry_order == "yes":
    fry_size = raw_input("Would you like a Small ($1.00), medium ($1.50), or large ($2.00)?")
    if fry_size == "small":
        mega_size = raw_input("Would you like to megae size, yes or no?")
        if mega_size == "yes":
            cost += 2.25
        else:
            cost += 1
    elif fry_size == "medium":
        cost += 1.75
    elif fry_size == "large":
        cost += 2.25
    else:
        print "Alright, no fries for you."
        fries = False #This line only gets added during the last part of the activity
else:
    print("Got it. No fries.")
    fries = False #This line only gets added during the last part of the activity

#getting the number of ketchup packets
number_ketchup_packets = int(raw_input("How many ketchup packets would you like? "))
cost += 0.25 * number_ketchup_packets


#checking if person gets combo discount
if sandwhich == True and drink == True and fries == True:
    cost -= 1
    print "Combo Discount"
    
    
#Doing the final report of what was bought and the price
print "I have your order as:"
if sandwhich == True:
    print food, "sandwhich"
if drink == True:
        print drink_size, "drink" #The , between items does concatentation
if fries == True:
    print fry_size, "Fries"
if number_ketchup_packets > 0:
    print number_ketchup_packets, "ketchup packets"
print cost, "is your total."
'''