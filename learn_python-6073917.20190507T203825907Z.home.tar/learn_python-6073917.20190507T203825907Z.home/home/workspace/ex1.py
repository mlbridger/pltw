print("Hello World!")
print("Hello Again")
print("I like typing this.")
