"""
This program is intended as a tracer round for the flow of control as a user
of a social media account makes, deletes, and edits posts. For testing,
a user should be able to enter their user name, change which user name they
are currently using, add a post using their current user name, remove a post
made under their current user name, edit a post made under their current user 
name, print the contents of the list of posts, or quit the program.
"""

#This line of code tells the Python interpreter that it needs to reference the 
#post.py file in order to run the rest of the code in this file.
from CSE_313_post import Post

user_input = raw_input(""" What would you like to do?
"add" - Add a post to the archive
"remove" - Remove a post from the archive
"change user" - Change the user name associated with any future posts
"edit" - Edit the message of a post made by the current user
"print" - Display the current up to date list of all posts
"quit" - End the program

""")

user_name = "default"
post_list = []

#This while loop ensures that the program will continue executing statements
# at the next indentation level until the user types "quit" in response to the 
# prompt.
while user_input != "quit":
    if user_input == "add":
        #code for adding a post here
        post = Post(user_name, raw_input("Please enter your message: "))
        post_list.append(post)
    elif user_input == "remove":
        #code for removing a post here
        request = int(raw_input("Which post # would you like to remove?: "))
        if len(post_list) > request:
            print post_list[request].get_user_name()
            print user_name
            if post_list[request].get_user_name() == user_name:
                del post_list[request]
            else:
                print "Error 1: Invalid Credentials"
        else:
            print "Error 2: Invalid list index"
    elif user_input == "change user":
        #code for changing the current user here
        user_name = raw_input("To which user name would you like to switch?: ")
    elif user_input == "edit":
        #code to edit a post made by the current user here
        request = int(raw_input("Which post # would you like to edit?: "))
        if len(post_list) > request:
            if post_list[request].get_user_name() == user_name:
                print "The post you will edit is: " + post_list[request].__str__()
                post_list[request].set_message(raw_input("Please enter your new message: "))
            else:
                print "Error 1: Invalid Credentials"
        else:
            print "Error 2: Invalid list index"
    elif user_input == "print":
        #code to display all posts
        for post in post_list:
            print post
    else:
        #code to inform the user that their input was not valid here
        print "Error 3: Invalid command."
    user_input = raw_input(""" What would you like to do?
"add" - Add a post to the archive
"remove" - Remove a post from the archive
"change user" - Change the user name associated with any future posts
"edit" - Edit the message of a post made by the current user
"print" - Display the current up to date list of all posts
"quit" - End the program

""")